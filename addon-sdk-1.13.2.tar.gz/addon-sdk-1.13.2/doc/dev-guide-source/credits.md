<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

# Credits #

We'd like to thank our many Jetpack project contributors!  They include:

* Adamantium
* Ehsan Akhgari
* arky
* [Heather Arthur](https://github.com/harthur)
* Dietrich Ayala
* [Romain B](https://github.com/Niamor)
* Will Bamberg
* Zbigniew Braniecki
* Daniel Buchner
* James Burke
* [Shane Caraveo](https://github.com/mixedpuppy)
* [Matěj Cepl](https://github.com/mcepl)
* Hernán Rodriguez Colmeiro
* [David Creswick](https://github.com/dcrewi)
* dexter
* [Matteo Ferretti (ZER0)](https://github.com/ZER0)
* fuzzykiller
* [Marcio Galli](https://github.com/taboca)
* [Ben Gillbanks](http://www.iconfinder.com/browse/iconset/circular_icons/)
* Felipe Gomes
* Irakli Gozalishvili
* Luca Greco
* Mark Hammond
* Lloyd Hilaiel
* Bobby Holley
* Eric H. Jung
* Hrishikesh Kale
* Wes Kocher
* Edward Lee
* Myk Melez
* Zandr Milewski
* Noelle Murata
* Joe R. Nassimian ([placidrage](https://github.com/placidrage))
* Nick Nguyen
* [ongaeshi](https://github.com/ongaeshi)
* Paul O’Shannessy
* l.m.orchard
* Alexandre Poirot
* Nickolay Ponomarev
* Aza Raskin
* Till Schneidereit
* Justin Scott
* Ayan Shah
* [skratchdot](https://github.com/skratchdot)
* [Mihai Sucan](https://github.com/mihaisucan)
* Clint Talbert
* Thomas
* Dave Townsend
* Peter Van der Beken
* Atul Varma
* [Erik Vold](https://github.com/erikvold)
* Vladimir Vukicevic
* Brian Warner
* [Henri Wiechers](https://github.com/hwiechers)
* Drew Willcoxon
* Piotr Zalewa
* [David Guo](https://github.com/dglol)
* [Nils Maier](https://github.com/nmaier)
* [Louis-Rémi Babé](https://github.com/louisremi)
* [Matthias Tylkowski](https://github.com/tylkomat)
