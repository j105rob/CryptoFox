<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

The Reddit Panel example add-on displays Reddit in a panel you open
by clicking a widget in the add-on bar.  When you click a Reddit story
in the panel, the story opens in a new tab.

The add-on demonstrates the Panel and Widget APIs as well as content scripts
and using jQuery as a content script.

Due to a bug in Firefox 4.0b7, this example doesn't work in that version
of Firefox and requires a recent Firefox 4.0b8pre nightly build, Firefox 4.0b8
itself, or a newer version of Firefox.
