<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

The `anteater` module should not be used by anyone.

<api name="release">
@function
  Releases the anteater. Do not call this function.
</api>
